# CE Construction — CURRENT_SPRINT.md
### Referencia oficial del Sprint en curso

> Documento pequeño, preciso y siempre actualizado al finalizar cada Entregable. Su objetivo es permitir continuar un Sprint interrumpido sin releer toda la documentación del proyecto. No duplica información ya detallada en `PROJECT_STATUS.md` — solo resume lo esencial para retomar el trabajo de inmediato.

---

## Sprint actual

**Sprint 6B — "Blog y páginas genéricas"**
**Estado:** En progreso

## Entregables

- Entregable 6B.1 — ✅ Completado (`page.php`)
- Entregable 6B.2 — ✅ Completado (`single.php` + `comments.php`)
- Entregable 6B.3 — ⬜ Pendiente (`404.php`) — **siguiente**

## Trabajo realizado (último Entregable: 6B.2)

`single.php` (entrada de blog: hero interno, meta autor/fecha/categorías, tags, navegación entre entradas, comentarios integrados) + `comments.php` (callback propio de comentarios con hilos anidados, paginación, formulario integrado al sistema de diseño). Extensión aditiva de Schema.org (`BlogPosting`) en `inc/seo.php` y nueva sección CSS (23) en `main.css` para el árbol de comentarios.

## Archivos creados (Sprint 6B, acumulado)

- `page.php` (Entregable 6B.1)
- `single.php` (Entregable 6B.2)
- `comments.php` (Entregable 6B.2)

## Archivos modificados (Sprint 6B, acumulado)

- `inc/seo.php` (extensión aditiva — Schema `BlogPosting`, Entregable 6B.2)
- `assets/css/main.css` (extensión aditiva — sección 23, árbol de comentarios, Entregable 6B.2)

## Documentación actualizada (al cierre del Entregable 6B.2)

`PROJECT_STATUS.md`, `TODO.md`, `TREE.md`, `CHANGELOG.md`, `DECISIONS.md`, `HANDOFF.md`.

## Próximo Entregable

**6B.3 — `404.php`** (último del Sprint 6B; al completarse, el Sprint 6B queda COMPLETADO).

## Riesgos abiertos (específicos de este Sprint)

Ninguno nuevo. Riesgos generales del proyecto (CDNs externos, hallazgos QA Medios/Bajos sin corregir) siguen documentados en `PROJECT_STATUS.md` sección 6 y no bloquean el cierre de este Sprint.

## Observaciones

- `404.php` debe reutilizar el mismo patrón ya validado en la rama `is_404()` de `index.php` (mismo mensaje, mismo `template-parts/no-results.php`) para no duplicar código — es, en esencia, extraer esa rama a su propio archivo dedicado, que WordPress preferirá automáticamente sobre `index.php` en cuanto exista.
- No se prevé necesidad de extender `inc/helpers.php`, `inc/seo.php`, `main.css` ni `main.js` para `404.php`, dado que reutiliza componentes ya existentes (`page-hero.php` opcional o encabezado simple, `.ce-card`, `.ce-btn`, `no-results.php`).
- A partir de este Sprint rige la nueva política de actualización incremental de documentación: solo se tocan los documentos cuyo contenido realmente cambió en cada Entregable (ver `HANDOFF.md` sección 16 y `DECISIONS.md` para el detalle).
