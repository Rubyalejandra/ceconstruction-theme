<?php
/**
 * AJAX Quote Form Handler
 *
 * Procesa el formulario de cotización.
 *
 * @package CE_Construction
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Procesa la solicitud.
 */
function ce_submit_quote() {

	check_ajax_referer( 'ce_quote_form_action', 'nonce' );

	// Honeypot
	if ( ! empty( $_POST['ce_website'] ) ) {
		wp_send_json_error( array(
			'message' => __( 'Solicitud inválida.', 'ce-construction' ),
		), 400 );
	}

	$name    = sanitize_text_field( $_POST['name'] ?? '' );
	$email   = sanitize_email( $_POST['email'] ?? '' );
	$phone   = sanitize_text_field( $_POST['phone'] ?? '' );
	$company = sanitize_text_field( $_POST['company'] ?? '' );
	$service = sanitize_text_field( $_POST['service'] ?? '' );
	$message = sanitize_textarea_field( $_POST['message'] ?? '' );

	if (
		empty( $name ) ||
		empty( $email ) ||
		empty( $phone ) ||
		empty( $service ) ||
		empty( $message )
	) {
		wp_send_json_error(
			array(
				'message' => __( 'Todos los campos obligatorios deben completarse.', 'ce-construction' ),
			),
			400
		);
	}

	if ( ! is_email( $email ) ) {
		wp_send_json_error(
			array(
				'message' => __( 'Correo electrónico inválido.', 'ce-construction' ),
			),
			400
		);
	}

	$to = get_option( 'admin_email' );

	$subject = sprintf(
		__( 'Nueva cotización - %s', 'ce-construction' ),
		$name
	);

	$body  = "Nombre: {$name}\n";
	$body .= "Correo: {$email}\n";
	$body .= "Teléfono: {$phone}\n";
	$body .= "Empresa: {$company}\n";
	$body .= "Servicio: {$service}\n\n";
	$body .= "Mensaje:\n{$message}\n";

	$headers = array(
		'Reply-To: ' . $name . ' <' . $email . '>',
	);

	$sent = wp_mail(
		$to,
		$subject,
		$body,
		$headers
	);

	if ( ! $sent ) {
		wp_send_json_error(
			array(
				'message' => __( 'No fue posible enviar la solicitud.', 'ce-construction' ),
			),
			500
		);
	}

	wp_send_json_success(
		array(
			'message' => __( 'Solicitud enviada correctamente.', 'ce-construction' ),
		)
	);
}

add_action( 'wp_ajax_ce_submit_quote', 'ce_submit_quote' );
add_action( 'wp_ajax_nopriv_ce_submit_quote', 'ce_submit_quote' );
